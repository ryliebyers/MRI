#include "globals.h"

int totalPoints =0;

int DropsCaught=0;

bool level1Clicked = false;
bool level2Clicked = false;
bool level3Clicked = false;
