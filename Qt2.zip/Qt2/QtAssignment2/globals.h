#ifndef GLOBALS_H
#define GLOBALS_H

#include <QObject>


extern int totalPoints;
extern int DropsCaught;
extern bool level1Clicked;
extern bool level2Clicked;
extern bool level3Clicked;
#endif // GLOBALS_H
