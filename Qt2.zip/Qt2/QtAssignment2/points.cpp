#include "points.h"
#include <QHBoxLayout>
#include "globals.h"
//#include "droplet.h"
Points::Points(QObject *parent)
    : QObject{parent},  m_points(0)
{

}
bool Points::isWon() const
{
    bool iswon = false;
    if(m_points == 150){
        iswon = true;
    }
    return iswon;
}

void Points::addPoints(int amount)
{
    m_points += amount;
    emit pointsChanged(m_points);
}

void Points::minusPoints(int amount)
{
    m_points -= amount;
    emit pointsChanged(m_points);
}

int Points::getPoints() const
{
    return m_points;
}

void Points::updatePointsLabel()
{
    m_label->setText(QString("Points: %1").arg(m_points));

}
